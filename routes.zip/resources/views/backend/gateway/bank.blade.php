 @extends('backend.layout.master')

@section('element')
    <div class="row">

        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="form-group col-md-3">
                                <label>{{ __('Gateway Image') }}</label>
                                <div id="image-preview" class="image-preview"
                                    style="background-image:url({{ Config::getFile('gateways', $gateway->image, true) }});">
                                    <label for="image-upload" id="image-label">{{ __('Choose File') }}</label>
                                    <input type="file" name="image" id="image-upload" />
                                </div>


                                <label class="mt-3 qr">{{ __('Qr Code Image') }}</label>

                                <div id="image-preview-1" class="image-preview qr"
                                    style="background-image:url({{ Config::getFile('gateways', $gateway->parameter->qr_code, true) }});">
                                    <label for="image-upload-1" id="image-label-1">{{ __('Choose File') }}</label>
                                    <input type="file" name="qr_code" id="image-upload-1" />
                                </div>
                            </div>

                            <div class="col-md-9">
                                <div class="row">
                                    <div class="mb-4 col-md-6">
                                        <label for="">{{ __('Gateway Name') }}</label>
                                        <input type="text" name="name" class="form-control"
                                            value="{{ $gateway->parameter->name }}">
                                    </div>

                                    <div class="mb-4 col-md-6" id="append">
                                        <label for="">{{ __('Gateway Type') }}</label>
                                        <select name="gateway_type" id="type" class="form-control">
                                            <option value="bank"
                                                {{ $gateway->parameter->gateway_type == 'bank' ? 'selected' : '' }}>
                                                {{ __('Bank') }}</option>
                                            <option value="crypto"
                                                {{ $gateway->parameter->gateway_type == 'crypto' ? 'selected' : '' }}>
                                                {{ __('Crypto') }}</option>
                                        </select>
                                    </div>

                                    <div class="mb-4 col-md-6">
                                        <label for="">{{ __('Gateway Currency') }}</label>
                                        <input type="text" name="gateway_currency" class="form-control site-currency"
                                            value="{{ $gateway->parameter->gateway_currency ?? '' }}">
                                    </div>

                                    <div class="mb-4 col-md-6">
                                        <label>{{ __('Conversion Rate') }}</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    {{ '1 ' . Config::config()->currency . ' = ' }}
                                                </div>
                                            </div>
                                            <input type="text" class="form-control currency" name="rate"
                                                value="{{ Config::formatter($gateway->rate) ?? 0 }}">

                                            <div class="input-group-append">
                                                <div class="input-group-text append_currency">

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-4 col-md-6">
                                        <label>{{ __('Charge') }}</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    {{ Config::config()->currency }}
                                                </div>
                                            </div>
                                            <input type="text" class="form-control currency" name="charge"
                                                value="{{ Config::formatOnlyNumber($gateway->charge) ?? 0 }}">
                                        </div>
                                    </div>

                                    <div class="mb-4 col-md-12">
                                        <label for="">{{ __('Payment Instruction') }}</label>
                                        <textarea name="payment_instruction" cols="30" rows="10" class="form-control summernote"><?= clean($gateway->parameter->payment_instruction) ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="card border">
                                    <div class="card-header">
                                        <h4>{{ __('User Proof Requirements') }}</h4>
                                        <button type="button" class="btn btn-primary ml-auto payment">
                                            <i class="fa fa-plus text-white"></i>
                                            {{ __('Add Payment Requirements') }}
                                        </button>
                                    </div>

                                    <div class="card-body">
                                        <div class="row payment-instruction">
                                            <div class="col-md-12 user-data">
                                                <div class="row">
                                                    @if ($gateway->parameter->user_proof_param != null)
                                                        @foreach ($gateway->parameter->user_proof_param as $key => $param)

                                                        
                                                            <div class="col-md-12 user-data">
                                                                <div class="form-group">
                                                                    <div class="input-group mb-md-0 mb-4">
                                                                        <div class="col-md-4">
                                                                            <label>{{ __('Field Name') }}</label>
                                                                            <input
                                                                                name="user_proof_param[{{ $key }}][field_name]"
                                                                                class="form-control rounded-5 form_control"
                                                                                type="text"
                                                                                value="{{ $param->field_name }}"
                                                                                required>
                                                                        </div>
                                                                        <div class="col-md-3 mt-md-0 mt-2">
                                                                            <label>{{ __('Field Type') }}</label>
                                                                            <select
                                                                                name="user_proof_param[{{ $key }}][type]"
                                                                                class="form-control rounded-5 selectric">
                                                                                <option value="text"
                                                                                    {{ $param->type == 'text' ? 'selected' : '' }}>
                                                                                    {{ __('Input Text') }}
                                                                                </option>
                                                                                <option value="textarea"
                                                                                    {{ $param->type == 'textarea' ? 'selected' : '' }}>
                                                                                    {{ __('Textarea') }}
                                                                                </option>
                                                                                <option value="file"
                                                                                    {{ $param->type == 'file' ? 'selected' : '' }}>
                                                                                    {{ __('File upload') }}
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-md-3 mt-md-0 mt-2">
                                                                            <label>{{ __('Field Validation') }}</label>
                                                                            <select
                                                                                name="user_proof_param[{{ $key }}][validation]"
                                                                                class="form-control rounded-5 selectric">
                                                                                <option value="required"
                                                                                    {{ $param->validation== 'required' ? 'selected' : '' }}>
                                                                                    {{ __('Required') }}
                                                                                </option>
                                                                                <option value="nullable"
                                                                                    {{ $param->validation== 'nullable' ? 'selected' : '' }}>
                                                                                    {{ __('Optional') }}
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-md-2 text-right my-auto ">

                                                                            <button
                                                                                class="btn btn-danger btn-lg remove w-100 mt-4"
                                                                                type="button">
                                                                                <i class="fa fa-times"></i>
                                                                            </button>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Update Bank Information') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('script')
    <script>
        $(function() {
            'use strict'

            let crypto = `
                <div class="mb-4 col-md-6 delete">
                    <label for="">{{ __('Bank Account Number') }}</label>
                    <input type="text" name="account_number" class="form-control"
                        value="{{ $gateway->parameter->account_number }}">
                </div>

                <div class="mb-4 col-md-6 delete">
                    <label for="">{{ __('Bank Routing Number') }}</label>
                    <input type="text" name="routing_number" class="form-control"
                        value="{{ $gateway->parameter->routing_number }}">
                </div>

                <div class="mb-4 col-md-6 delete">
                    <label for="">{{ __('Bank Branch Name') }}</label>
                    <input type="text" name="branch_name" class="form-control"
                        value="{{ $gateway->parameter->branch_name }}">
                </div>
            `;

            @if ($gateway->parameter->gateway_type == 'bank')
                $('#append').after(crypto)
                $('.qr').addClass('d-none')
            @endif


            $('#type').on('change', function() {
                if ($(this).val() === 'bank') {
                    $('#append').after(crypto);
                    $('.qr').removeClass('d-block').addClass('d-none')
                    $('.qr').find('input[name=qr_code]').val('')
                } else {
                    $('.qr').removeClass('d-none').addClass('d-block')
                    $('.delete').remove();
                }
            })



            var i = {{ count($gateway->parameter->user_proof_param ?? []) }};

            $('.payment').on('click', function() {

                var html = `
                <div class="col-md-12 user-data">
                    <div class="form-group">
                        <div class="input-group mb-md-0 mb-4">
                            <div class="col-md-4">
                                <label>{{ __('Field Name') }}</label>
                                <input name="user_proof_param[${i}][field_name]" class="form-control rounded-5 form_control" type="text" value="" required >
                            </div>
                            <div class="col-md-3 mt-md-0 mt-2">
                                <label>{{ __('Field Type') }}</label>
                                <select name="user_proof_param[${i}][type]" class="form-control rounded-5 selectric">
                                    <option value="text" > {{ __('Input Text') }} </option>
                                    <option value="textarea" > {{ __('Textarea') }} </option>
                                    <option value="file"> {{ __('File upload') }} </option>
                                </select>
                            </div>
                            <div class="col-md-3 mt-md-0 mt-2">
                                <label>{{ __('Field Validation') }}</label>
                                <select name="user_proof_param[${i}][validation]"
                                        class="form-control rounded-5 selectric">
                                    <option value="required"> {{ __('Required') }} </option>
                                    <option value="nullable">  {{ __('Optional') }} </option>
                                </select>
                            </div>
                            <div class="col-md-2 text-right my-auto">
                              
                                    <button class="btn btn-danger btn-lg remove w-100 mt-4" type="button">
                                        <i class="fa fa-times"></i>
                                    </button>
                                
                            </div>
                        </div>
                    </div>
                </div>`;
                $('.payment-instruction').append(html);

                i++;

            })

            $(document).on('click', '.remove', function() {
                $(this).closest('.user-data').remove();
            });

            $.uploadPreview({
                input_field: "#image-upload", // Default: .image-upload
                preview_box: "#image-preview", // Default: .image-preview
                label_field: "#image-label", // Default: .image-label
                label_default: "{{ __('Choose File') }}", // Default: Choose File
                label_selected: "{{ __('Update Image') }}", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });

            $.uploadPreview({
                input_field: "#image-upload-1", // Default: .image-upload
                preview_box: "#image-preview-1", // Default: .image-preview
                label_field: "#image-label-1", // Default: .image-label
                label_default: "{{ __('Choose File') }}", // Default: Choose File
                label_selected: "{{ __('Update Image') }}", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });

            $('.site-currency').on('keyup', function() {
                $('.append_currency').text($(this).val())
            })

            $('.append_currency').text($('.site-currency').val())
        })
    </script>
@endpush
